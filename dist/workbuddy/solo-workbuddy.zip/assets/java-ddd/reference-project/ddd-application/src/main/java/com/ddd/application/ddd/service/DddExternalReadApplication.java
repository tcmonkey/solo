package com.ddd.application.ddd.service;

import com.ddd.application.ddd.adaptor.DddOutputAdaptor;
import com.ddd.application.ddd.assembler.DddApplicationAssembler;
import com.ddd.application.ddd.command.DddExternalReadCommand;
import com.ddd.application.ddd.result.DddExternalResult;
import com.ddd.common.result.Result;
import com.ddd.model.ddd.DddExternalReadDO;

import org.springframework.stereotype.Service;

/**
 * DDD 外部数据查询的应用服务模板。
 *
 * <p>这是“读模式查询外部系统”的示例：application 只依赖自身定义的端口， output adaptor 负责外部调用与模型转换。
 *
 * @author AIGenerator
 */
@Service
public final class DddExternalReadApplication {

    private final DddOutputAdaptor outputAdaptor;
    private final DddApplicationAssembler assembler;

    public DddExternalReadApplication(
            DddOutputAdaptor outputAdaptor, DddApplicationAssembler assembler) {
        this.outputAdaptor = outputAdaptor;
        this.assembler = assembler;
    }

    /**
     * 查询外部数据并转换为应用层结果。
     *
     * @param dddExternalReadCommand 外部读取应用命令
     * @return 外部数据查询结果
     * @author AIGenerator
     */
    public Result<DddExternalResult> query(DddExternalReadCommand dddExternalReadCommand) {
        try {
            // 1. 调用输出适配端口获取项目内部 DO。
            Result<DddExternalReadDO> externalResult = outputAdaptor.query(dddExternalReadCommand);
            if (!externalResult.success()) {
                return Result.failure(externalResult.code(), externalResult.message());
            }
            // 2. 将内部 DO 转换为应用层结果，避免向 Controller 泄漏领域模型。
            DddExternalReadDO dataObject = externalResult.data();
            DddExternalResult result = assembler.toResult(dataObject);
            return Result.success(result);
        } catch (Exception exception) {
            return com.ddd.common.error.Failures.capture(
                    exception,
                    com.ddd.application.exception.ApplicationErrorCode.APPLICATION_PROCESS_FAILED);
        }
    }
}
