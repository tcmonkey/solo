#!/usr/bin/env python3
"""Forward-test Java DDD guardrails in disposable, independent Maven projects."""

from __future__ import annotations

import os
import subprocess
import tempfile
import unittest
from pathlib import Path

from install_java_ddd_checks import integrate


CORE = Path(__file__).resolve().parent.parent
INSTALLER = CORE / "scripts/install_java_ddd_checks.py"
APPLICATION = """package example.demo.application.demo.service;

import example.demo.application.demo.command.DemoCommand;
import example.demo.application.demo.assembler.DemoApplicationAssembler;
import example.demo.application.demo.result.DemoResult;
import example.demo.common.result.Result;

/**
 * 独立工程的公开入口校验样本。
 *
 * @author AIGenerator
 */
public class DemoApplication {
    /**
     * 查询并生成应用结果。
     *
     * @param demoCommand 查询命令
     * @return 统一应用结果
     *
     * @author AIGenerator
     */
    public Result<DemoResult> query(DemoCommand demoCommand) {
        try {
            // 1. 从命令取得业务标识并创建应用结果。
            DemoResult result = DemoApplicationAssembler.toResult(demoCommand);
            // 2. 将应用结果包装为统一成功响应。
            return new Result<>(result);
        } catch (Exception exception) {
            return new Result<>(null);
        }
    }
}
"""


class GuardrailTest(unittest.TestCase):
    def setUp(self):
        self.directory = tempfile.TemporaryDirectory(prefix="java-ddd-guardrails-")
        self.addCleanup(self.directory.cleanup)
        self.root = Path(self.directory.name)
        self.write("pom.xml", """<project xmlns="http://maven.apache.org/POM/4.0.0">
    <modelVersion>4.0.0</modelVersion>
    <groupId>example.demo</groupId>
    <artifactId>demo</artifactId>
    <version>1.0</version>
    <packaging>pom</packaging>
    <modules>
        <module>demo-application</module>
    </modules>
    <build>
        <plugins>
            <plugin>
                <groupId>org.apache.maven.plugins</groupId>
                <artifactId>maven-compiler-plugin</artifactId>
                <version>3.13.0</version>
                <configuration>
                    <release>17</release>
                </configuration>
            </plugin>
        </plugins>
    </build>
</project>
""")
        self.write("demo-application/pom.xml", """<project xmlns="http://maven.apache.org/POM/4.0.0">
    <modelVersion>4.0.0</modelVersion>
    <parent>
        <groupId>example.demo</groupId>
        <artifactId>demo</artifactId>
        <version>1.0</version>
    </parent>
    <artifactId>demo-application</artifactId>
</project>
""")
        self.source = "demo-application/src/main/java/"
        self.application = self.source + "example/demo/application/demo/service/DemoApplication.java"
        self.write(self.application, APPLICATION)
        for folder, name, component in [
            ("application/demo/command", "DemoCommand", "String id"),
            ("application/demo/result", "DemoResult", "String id"),
            ("common/result", "Result<T>", "T data"),
        ]:
            generic = " * @param <T> 成功数据类型\n" if "<" in name else ""
            component_name = component.split()[-1]
            self.write(self.source + "example/demo/" + folder + "/" + name.split("<")[0] + ".java",
                       "package example.demo." + folder.replace("/", ".") + ";\n\n"
                       + "/**\n * 独立工程的稳定数据对象。\n *\n"
                       + generic + " * @param " + component_name + " 数据内容\n *\n"
                       + " * @author AIGenerator\n */\n"
                       + "public record " + name + "(" + component + ") {\n}\n")

        self.write(self.source + "example/demo/application/demo/assembler/DemoApplicationAssembler.java", """package example.demo.application.demo.assembler;
import example.demo.application.demo.command.DemoCommand;
import example.demo.application.demo.result.DemoResult;
/**
 * 整体映射独立工程的应用视图。
 *
 * @author AIGenerator
 */
public final class DemoApplicationAssembler {
    /**
     * 投影完整命令快照。
     *
     * @param command 命令快照
     * @return 应用结果
     * @author AIGenerator
     */
    public static DemoResult toResult(DemoCommand command) {
        return new DemoResult(command.id());
    }
}
""")

    def write(self, name, content):
        target = self.root / name
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(content, encoding="utf-8")

    def install(self):
        result = subprocess.run(
            ["python3", str(INSTALLER), "--project", str(self.root)],
            capture_output=True, text=True, timeout=30,
        )
        self.assertEqual(0, result.returncode, result.stdout + result.stderr)

    def maven(self, *arguments):
        return subprocess.run(
            ["mvn", "-q", *arguments], cwd=self.root,
            capture_output=True, text=True, timeout=180,
        )

    def test_fresh_project_compiles_and_install_is_idempotent(self):
        self.install()
        before = (self.root / "pom.xml").read_bytes()
        self.install()
        self.assertEqual(before, (self.root / "pom.xml").read_bytes())
        self.assertEqual(
            (CORE / "assets/java-ddd/checkstyle.xml").read_bytes(),
            (self.root / "checkstyle.xml").read_bytes(),
        )
        self.assertTrue((self.root / "AI/output/19 Java DDD开发规范.md").is_file())
        result = self.maven("clean", "compile")
        self.assertEqual(0, result.returncode, result.stdout + result.stderr)
        self.assertTrue((self.root / "demo-application/target/classes").is_dir())

    def test_business_quality_violations_stop_before_javac(self):
        self.install()
        variants = [
            ("QUALITY-STEPS", APPLICATION.replace(
                "            // 1. 从命令取得业务标识并创建应用结果.\n", "").replace(
                "            // 1. 从命令取得业务标识并创建应用结果。\n", "").replace(
                "            // 2. 将应用结果包装为统一成功响应。\n", "")),
            ("QUALITY-STEPS", APPLICATION.replace("// 2.", "// 3.")),
            ("QUALITY-STEPS", APPLICATION.replace(
                "从命令取得业务标识并创建应用结果。", "prepare result")),
            ("QUALITY-SIZE", APPLICATION.replace(
                "    public Result<DemoResult> query", "    private void oversized() {\n"
                "        // 1. 初始化计数器。\n        int count = 0;\n"
                + "        count++;\n" * 46
                + "        // 2. 输出当前计数。\n        System.out.println(count);\n    }\n"
                "    public Result<DemoResult> query")),
        ]
        for marker, variant in variants:
            with self.subTest(marker=marker):
                self.write(self.application, variant)
                result = self.maven("compile")
                self.assertNotEqual(0, result.returncode, result.stdout + result.stderr)
                self.assertIn(marker, result.stdout + result.stderr)
                self.assertFalse((self.root / "demo-application/target/classes").exists())
        self.write(self.application, APPLICATION)

    def test_violations_stop_compile_before_javac(self):
        self.install()
        variants = {
            "ERR-BOUNDARY-CATCH": APPLICATION.replace("        try {\n", "").replace(
                "        } catch (Exception exception) {\n            return new Result<>(null);\n        }\n", ""
            ),
            "ERR-BOUNDARY-THROWS": APPLICATION.replace(
                "query(DemoCommand demoCommand) {", "query(DemoCommand demoCommand) throws Exception {"
            ),
            "ERR-BOUNDARY-RETHROW": APPLICATION.replace("return new Result<>(null);", "throw exception;"),
            "NAM-APP-PARAM": APPLICATION.replace("demoCommand", "command"),
            "NAM-TYPE-PARAM": APPLICATION.replace("demoCommand", "wrongCommand"),
            "SIG-APP-OUTPUT": APPLICATION.replace("Result<DemoResult>", "Result<DemoCommand>"),
            "NAM-APP-ACTION": APPLICATION.replace(" query(", " execute("),
            "DOC-AUTHOR": APPLICATION.replace(" * @author AIGenerator\n", ""),
            "MissingJavadocMethod": APPLICATION.replace(
                APPLICATION[APPLICATION.index("    /**"):APPLICATION.index("    public Result")], ""
            ),
            "DI-FIELD": APPLICATION.replace(
                "public class DemoApplication {",
                "public class DemoApplication {\n"
                "    /**\n     * 注入违规样本。\n     *\n     * @author AIGenerator\n     */\n"
                "    @org.springframework.beans.factory.annotation.Autowired\n"
                "    private DemoCommand dependency;\n",
            ),
            "SQL-CUSTOM": APPLICATION.replace(
                "    public Result", '    @org.apache.ibatis.annotations.Select("select 1")\n    public Result'
            ),
        }
        for marker, source in variants.items():
            with self.subTest(rule=marker):
                self.write(self.application, source)
                result = self.maven("compile")
                output = result.stdout + result.stderr
                self.assertNotEqual(0, result.returncode, output)
                self.assertIn(marker, output)
                self.assertFalse((self.root / "demo-application/target/classes").exists())
        self.write(self.application, APPLICATION)
        result = self.maven("compile")
        self.assertEqual(0, result.returncode, result.stdout + result.stderr)

    def test_domain_structure_violations_stop_before_javac(self):
        self.install()
        service = self.source + "example/demo/domain/demo/service/DemoDomainService.java"
        self.write(self.application, APPLICATION.replace(
            "DemoResult result =",
            "Object entity = new example.demo.domain.demo.model.entity.DemoEntity();\n"
            "            DemoResult result =",
        ))
        result = self.maven("compile")
        self.assertNotEqual(0, result.returncode)
        self.assertIn("QUALITY-DOMAIN", result.stdout + result.stderr)
        self.assertFalse((self.root / "demo-application/target/classes").exists())
        self.write(self.application, APPLICATION)
        self.write(service, """package example.demo.domain.demo.service;
public class DemoDomainService {
    public void write() {
        // 1. 取得待保存聚合。
        DemoAggregate aggregate = load();
        // 2. 展开实体是需要阻止的结构反例。
        aggregate.entity();
    }
}
""")
        result = self.maven("compile")
        self.assertNotEqual(0, result.returncode)
        self.assertIn("QUALITY-DOMAIN", result.stdout + result.stderr)
        self.assertFalse((self.root / "demo-application/target/classes").exists())
        (self.root / service).unlink()
        result = self.maven("compile")
        self.assertEqual(0, result.returncode, result.stdout + result.stderr)

    def test_mapping_and_exception_ownership_stop_before_compilation(self):
        self.install()
        mapping = APPLICATION.replace(
            "DemoApplicationAssembler.toResult(demoCommand)",
            "new DemoResult(demoCommand.id())",
        )
        ownership = APPLICATION.replace(
            "DemoResult result =",
            "Object error = new example.demo.domain.exception.DomainException(null);\n"
            "            DemoResult result =",
        )
        for marker, source in [("QUALITY-MAPPING", mapping),
                               ("QUALITY-ERROR-OWNER", ownership)]:
            with self.subTest(rule=marker):
                self.write(self.application, source)
                result = self.maven("compile")
                self.assertNotEqual(0, result.returncode, result.stdout + result.stderr)
                self.assertIn(marker, result.stdout + result.stderr)
                self.assertFalse((self.root / "demo-application/target/classes").exists())
        self.write(self.application, APPLICATION)
        result = self.maven("compile")
        self.assertEqual(0, result.returncode, result.stdout + result.stderr)

    def test_input_controller_and_assembler_require_sibling_packages(self):
        self.install()
        variants = {
            "DemoController.java": """package example.demo.adaptor.demo.input;
public final class DemoController {}
""",
            "DemoInputAssembler.java": """package example.demo.adaptor.demo.input;
public final class DemoInputAssembler {}
""",
        }
        for name, source in variants.items():
            with self.subTest(source=name):
                path = self.source + "example/demo/adaptor/demo/input/" + name
                self.write(path, source)
                result = self.maven("compile")
                output = result.stdout + result.stderr
                self.assertNotEqual(0, result.returncode, output)
                self.assertIn("QUALITY-PACKAGE", output)
                self.assertFalse((self.root / "demo-application/target/classes").exists())
                (self.root / path).unlink()
        result = self.maven("compile")
        self.assertEqual(0, result.returncode, result.stdout + result.stderr)

    def test_scheduled_method_requires_business_input_scheduler(self):
        self.install()
        source = """package example.demo.application.demo;
public final class DemoScheduledApplication {
    @org.springframework.scheduling.annotation.Scheduled(fixedDelay = 1)
    public void dispatch() {
        // 1. 触发应用业务动作。
        int attempts = 1;
        // 2. 保留本轮触发结果。
        System.out.println(attempts);
    }
}
"""
        path = self.source + "example/demo/application/demo/DemoScheduledApplication.java"
        self.write(path, source)
        result = self.maven("compile")
        output = result.stdout + result.stderr
        self.assertNotEqual(0, result.returncode, output)
        self.assertIn("QUALITY-SCHEDULER-BOUNDARY", output)
        self.assertFalse((self.root / "demo-application/target/classes").exists())
        (self.root / path).unlink()
        result = self.maven("compile")
        self.assertEqual(0, result.returncode, result.stdout + result.stderr)

    def test_implicit_public_interface_javadoc_is_enforced(self):
        self.install()
        name = self.source + "example/demo/common/api/DemoRepository.java"
        source = """package example.demo.common.api;

/**
 * 独立工程的接口契约校验样本。
 *
 * @author AIGenerator
 */
public interface DemoRepository {
    /**
     * 按标识查询内部数据。
     *
     * @param id 业务标识
     * @return 内部数据
     *
     * @author AIGenerator
     */
    String findById(String id);
}
"""
        method_doc = source[source.index("    /**"):source.index("    String findById")]
        variants = [
            ("MissingJavadocMethod", source.replace(method_doc, "")),
            ("JavadocMethod", source.replace("     * @param id 业务标识\n", "")),
            ("JavadocMethod", source.replace("     * @return 内部数据\n", "")),
            ("DOC-AUTHOR", source.replace("     * @author AIGenerator\n", "")),
        ]
        for index, (marker, variant) in enumerate(variants):
            with self.subTest(interface_violation=index):
                self.write(name, variant)
                result = self.maven("compile")
                output = result.stdout + result.stderr
                self.assertNotEqual(0, result.returncode, output)
                self.assertIn(marker, output)
                self.assertFalse((self.root / "demo-application/target/classes").exists())
        self.write(name, source)
        result = self.maven("compile")
        self.assertEqual(0, result.returncode, result.stdout + result.stderr)

    def test_conflicting_file_is_preserved_without_partial_pom_write(self):
        self.write("checkstyle.xml", "<user-config/>\n")
        original = (self.root / "pom.xml").read_bytes()
        result = subprocess.run(
            ["python3", str(INSTALLER), "--project", str(self.root)],
            capture_output=True, text=True, timeout=30,
        )
        self.assertNotEqual(0, result.returncode)
        self.assertEqual(original, (self.root / "pom.xml").read_bytes())
        self.assertEqual("<user-config/>\n", (self.root / "checkstyle.xml").read_text())
        self.assertFalse((self.root / "AI").exists())

    def test_business_quality_conflicts_preserve_project(self):
        before = (self.root / "pom.xml").read_bytes()
        self.write("scripts/JavaBusinessQuality.java", "// project-owned scanner\n")
        result = subprocess.run(
            ["python3", str(INSTALLER), "--project", str(self.root)],
            capture_output=True, text=True, timeout=30,
        )
        self.assertNotEqual(0, result.returncode)
        self.assertEqual(before, (self.root / "pom.xml").read_bytes())
        self.assertEqual("// project-owned scanner\n",
                         (self.root / "scripts/JavaBusinessQuality.java").read_text())
        self.assertFalse((self.root / "checkstyle.xml").exists())
        (self.root / "scripts/JavaBusinessQuality.java").unlink()
        existing = before.decode().replace(
            "        <plugins>",
            "        <plugins>\n            <plugin>\n"
            "                <groupId>org.codehaus.mojo</groupId>\n"
            "                <artifactId>exec-maven-plugin</artifactId>\n"
            "                <version>3.5.0</version>\n            </plugin>",
        )
        self.write("pom.xml", existing)
        result = subprocess.run(
            ["python3", str(INSTALLER), "--project", str(self.root)],
            capture_output=True, text=True, timeout=30,
        )
        self.assertNotEqual(0, result.returncode)
        self.assertEqual(existing, (self.root / "pom.xml").read_text())
        self.assertFalse((self.root / "checkstyle.xml").exists())
        self.assertFalse((self.root / "scripts/JavaBusinessQuality.java").exists())

    def test_pure_injection_constructors_and_fields_need_no_javadoc(self):
        self.install()
        # Local annotations test the AST scope, not Spring's runtime scanning.
        annotations = ["Component", "Service", "Repository", "Controller", "RestController",
                       "Configuration", "DomainService"]
        for annotation in annotations:
            self.write(self.source + "example/demo/common/" + annotation + ".java",
                       "package example.demo.common;\n\n/**\n * 扫描标记语法样本。\n *\n"
                       " * @author AIGenerator\n */\npublic @interface " + annotation + " {\n}\n")
            self.write(self.source + "example/demo/common/Demo" + annotation + ".java",
                       "package example.demo.common;\n\n/**\n * 纯依赖装配样本。\n *\n"
                       " * @author AIGenerator\n */\n@" + annotation + "\npublic class Demo" + annotation
                       + " {\n"
                       "    private final String dependency;\n\n    public Demo" + annotation
                       + "(String dependency) {\n        this.dependency = dependency;\n    }\n}\n")
        result = self.maven("clean", "compile")
        self.assertEqual(0, result.returncode, result.stdout + result.stderr)

        name = self.source + "example/demo/common/DemoComponent.java"
        valid = (self.root / name).read_text(encoding="utf-8")
        variants = {
            "validation": valid.replace("this.dependency = dependency;",
                                        'if (dependency == null) {\n'
                                        '            throw new IllegalArgumentException("dependency");\n'
                                        '        }\n        this.dependency = dependency;'),
            "initialization": valid.replace("this.dependency = dependency;",
                                            "this.dependency = dependency.trim();"),
            "unscanned": valid.replace("@Component\n", ""),
            "mutable_field": valid.replace("private final String", "private String"),
            "additional_assignment": valid.replace("this.dependency = dependency;",
                                                    "this.dependency = dependency;\n"
                                                    "        System.setProperty(\"demo\", dependency);"),
            "overloaded": valid.replace("\n}\n", "\n    public DemoComponent() {\n"
                                        "        this.dependency = null;\n    }\n}\n"),
        }
        for variant, source in variants.items():
            with self.subTest(constructor=variant):
                self.write(name, source)
                result = self.maven("validate")
                output = result.stdout + result.stderr
                self.assertNotEqual(0, result.returncode, output)
                self.assertIn("MissingJavadocMethod", output)
        # Exempt dependency fields only; do not hide business state or constants.
        for field in [
            '    private final String state = "ready";\n',
            '    private String state;\n',
            '    private static final String STATE = "ready";\n',
        ]:
            with self.subTest(undocumented_non_dependency=field):
                self.write(name, valid.replace("    private final String dependency;",
                                               field + "    private final String dependency;"))
                result = self.maven("validate")
                output = result.stdout + result.stderr
                self.assertNotEqual(0, result.returncode, output)
                self.assertIn("JavadocVariable", output)
        self.write(name, valid)
        result = self.maven("validate")
        self.assertEqual(0, result.returncode, result.stdout + result.stderr)

    def test_diagnostics_are_readable_with_different_output_charsets(self):
        self.install()
        self.write(self.application, APPLICATION.replace("demoCommand", "wrongCommand"))
        expected = ("NAM-TYPE-PARAM: Request/Command parameter name must match its full type "
                    "in lowerCamelCase")
        for charset in ["UTF-8", "US-ASCII"]:
            with self.subTest(output_charset=charset):
                environment = os.environ.copy()
                environment["MAVEN_OPTS"] = environment.get("MAVEN_OPTS", "") + (
                    " -Dfile.encoding=" + charset + " -Duser.language=zh -Duser.country=CN"
                )
                result = subprocess.run(["mvn", "-q", "compile"], cwd=self.root, env=environment,
                                        capture_output=True, timeout=180)
                output = (result.stdout + result.stderr).decode("utf-8", errors="strict")
                self.assertNotEqual(0, result.returncode, output)
                self.assertIn(expected, output)
                diagnostic = next(line for line in output.splitlines() if expected in line)
                self.assertTrue(diagnostic.isascii(), diagnostic)
                self.assertFalse((self.root / "demo-application/target/classes").exists())
        self.write(self.application, APPLICATION)
        result = self.maven("compile")
        self.assertEqual(0, result.returncode, result.stdout + result.stderr)

    def test_pom_shapes_and_existing_plugin_conflict(self):
        fragment = (CORE / "assets/java-ddd/maven-checkstyle-plugin.xml").read_text()
        original = (self.root / "pom.xml").read_text()
        without_build = original[:original.index("    <build>")] + "</project>\n"
        for shape in [original, without_build, original.replace("        <plugins>", "        <pluginManagement>\n            <plugins>")
                      .replace("        </plugins>", "            </plugins>\n        </pluginManagement>")]:
            installed = integrate(shape, fragment)
            self.assertEqual(installed, integrate(installed, fragment))
        conflict = integrate(original, fragment).replace("<failOnViolation>true", "<failOnViolation>false")
        with self.assertRaises(ValueError):
            integrate(conflict, fragment)


if __name__ == "__main__":
    unittest.main(verbosity=2)
